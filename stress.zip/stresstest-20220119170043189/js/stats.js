var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "3600",
        "ok": "2160",
        "ko": "1440"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "308"
    },
    "maxResponseTime": {
        "total": "13758",
        "ok": "13758",
        "ko": "4428"
    },
    "meanResponseTime": {
        "total": "1702",
        "ok": "1647",
        "ko": "1784"
    },
    "standardDeviation": {
        "total": "1500",
        "ok": "1794",
        "ko": "884"
    },
    "percentiles1": {
        "total": "1447",
        "ok": "449",
        "ko": "2041"
    },
    "percentiles2": {
        "total": "2724",
        "ok": "3355",
        "ko": "2306"
    },
    "percentiles3": {
        "total": "4396",
        "ok": "5075",
        "ko": "3156"
    },
    "percentiles4": {
        "total": "5579",
        "ok": "6550",
        "ko": "4390"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1191,
    "percentage": 33
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 60,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 909,
    "percentage": 25
},
    "group4": {
    "name": "failed",
    "count": 1440,
    "percentage": 40
},
    "meanNumberOfRequestsPerSecond": {
        "total": "225",
        "ok": "135",
        "ko": "90"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "205",
        "ok": "205",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1927",
        "ok": "1927",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1243",
        "ok": "1243",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "446",
        "ok": "446",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1260",
        "ok": "1260",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1585",
        "ok": "1585",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1888",
        "ok": "1888",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1911",
        "ok": "1911",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 15,
    "percentage": 19
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 21,
    "percentage": 26
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 44,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_jquery-3-3-1-sl-7cca6": {
        type: "REQUEST",
        name: "jquery-3.3.1.slim.min.js",
path: "jquery-3.3.1.slim.min.js",
pathFormatted: "req_jquery-3-3-1-sl-7cca6",
stats: {
    "name": "jquery-3.3.1.slim.min.js",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3252",
        "ok": "3252",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "11358",
        "ok": "11358",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "4670",
        "ok": "4670",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "943",
        "ok": "943",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4544",
        "ok": "4544",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4958",
        "ok": "4958",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5583",
        "ok": "5583",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6933",
        "ok": "6933",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 80,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_css2-family-rob-81fc9": {
        type: "REQUEST",
        name: "css2?family=Roboto+Mono:wght@600&display=swap",
path: "css2?family=Roboto+Mono:wght@600&display=swap",
pathFormatted: "req_css2-family-rob-81fc9",
stats: {
    "name": "css2?family=Roboto+Mono:wght@600&display=swap",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3097",
        "ok": "3097",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3821",
        "ok": "3821",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3403",
        "ok": "3403",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "191",
        "ok": "191",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3396",
        "ok": "3396",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3543",
        "ok": "3543",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3724",
        "ok": "3724",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3819",
        "ok": "3819",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 80,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_bootstrap-min-c-5b8a7": {
        type: "REQUEST",
        name: "bootstrap.min.css",
path: "bootstrap.min.css",
pathFormatted: "req_bootstrap-min-c-5b8a7",
stats: {
    "name": "bootstrap.min.css",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3151",
        "ok": "3151",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7154",
        "ok": "7154",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "5185",
        "ok": "5185",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "899",
        "ok": "899",
        "ko": "-"
    },
    "percentiles1": {
        "total": "5177",
        "ok": "5177",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5555",
        "ok": "5555",
        "ko": "-"
    },
    "percentiles3": {
        "total": "6877",
        "ok": "6877",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7104",
        "ok": "7104",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 80,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_bootstrap-min-j-13b2a": {
        type: "REQUEST",
        name: "bootstrap.min.js",
path: "bootstrap.min.js",
pathFormatted: "req_bootstrap-min-j-13b2a",
stats: {
    "name": "bootstrap.min.js",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3151",
        "ok": "3151",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "13758",
        "ok": "13758",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3994",
        "ok": "3994",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1548",
        "ok": "1548",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3508",
        "ok": "3508",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3677",
        "ok": "3677",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5624",
        "ok": "5624",
        "ko": "-"
    },
    "percentiles4": {
        "total": "9856",
        "ok": "9856",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 80,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-18-f5b64": {
        type: "REQUEST",
        name: "request_18",
path: "request_18",
pathFormatted: "req_request-18-f5b64",
stats: {
    "name": "request_18",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3083",
        "ok": "3083",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3809",
        "ok": "3809",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3398",
        "ok": "3398",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3396",
        "ok": "3396",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3533",
        "ok": "3533",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3712",
        "ok": "3712",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3808",
        "ok": "3808",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 80,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_popper-min-js-1c2ac": {
        type: "REQUEST",
        name: "popper.min.js",
path: "popper.min.js",
pathFormatted: "req_popper-min-js-1c2ac",
stats: {
    "name": "popper.min.js",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3157",
        "ok": "3157",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5521",
        "ok": "5521",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3767",
        "ok": "3767",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "710",
        "ok": "710",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3513",
        "ok": "3513",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3716",
        "ok": "3716",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5491",
        "ok": "5491",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5508",
        "ok": "5508",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 80,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_font-awesome-mi-e8a34": {
        type: "REQUEST",
        name: "font-awesome.min.css",
path: "font-awesome.min.css",
pathFormatted: "req_font-awesome-mi-e8a34",
stats: {
    "name": "font-awesome.min.css",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3210",
        "ok": "3210",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5532",
        "ok": "5532",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3702",
        "ok": "3702",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "630",
        "ok": "630",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3509",
        "ok": "3509",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3714",
        "ok": "3714",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5506",
        "ok": "5506",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5530",
        "ok": "5530",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 80,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-19-10d85": {
        type: "REQUEST",
        name: "request_19",
path: "request_19",
pathFormatted: "req_request-19-10d85",
stats: {
    "name": "request_19",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3210",
        "ok": "3210",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7242",
        "ok": "7242",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "4020",
        "ok": "4020",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1047",
        "ok": "1047",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3551",
        "ok": "3551",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4404",
        "ok": "4404",
        "ko": "-"
    },
    "percentiles3": {
        "total": "7102",
        "ok": "7102",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7189",
        "ok": "7189",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 80,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_sparta-favicon--960d6": {
        type: "REQUEST",
        name: "Sparta_Favicon.jpg",
path: "Sparta_Favicon.jpg",
pathFormatted: "req_sparta-favicon--960d6",
stats: {
    "name": "Sparta_Favicon.jpg",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "1025",
        "ok": "-",
        "ko": "1025"
    },
    "maxResponseTime": {
        "total": "3382",
        "ok": "-",
        "ko": "3382"
    },
    "meanResponseTime": {
        "total": "2724",
        "ok": "-",
        "ko": "2724"
    },
    "standardDeviation": {
        "total": "441",
        "ok": "-",
        "ko": "441"
    },
    "percentiles1": {
        "total": "2770",
        "ok": "-",
        "ko": "2770"
    },
    "percentiles2": {
        "total": "3059",
        "ok": "-",
        "ko": "3059"
    },
    "percentiles3": {
        "total": "3286",
        "ok": "-",
        "ko": "3286"
    },
    "percentiles4": {
        "total": "3380",
        "ok": "-",
        "ko": "3380"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_terraform-png-a46fb": {
        type: "REQUEST",
        name: "terraform.png",
path: "terraform.png",
pathFormatted: "req_terraform-png-a46fb",
stats: {
    "name": "terraform.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "857",
        "ok": "-",
        "ko": "857"
    },
    "maxResponseTime": {
        "total": "2388",
        "ok": "-",
        "ko": "2388"
    },
    "meanResponseTime": {
        "total": "2123",
        "ok": "-",
        "ko": "2123"
    },
    "standardDeviation": {
        "total": "183",
        "ok": "-",
        "ko": "183"
    },
    "percentiles1": {
        "total": "2092",
        "ok": "-",
        "ko": "2092"
    },
    "percentiles2": {
        "total": "2194",
        "ok": "-",
        "ko": "2194"
    },
    "percentiles3": {
        "total": "2346",
        "ok": "-",
        "ko": "2346"
    },
    "percentiles4": {
        "total": "2375",
        "ok": "-",
        "ko": "2375"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_ansiblelogo-png-b596d": {
        type: "REQUEST",
        name: "ansiblelogo.png",
path: "ansiblelogo.png",
pathFormatted: "req_ansiblelogo-png-b596d",
stats: {
    "name": "ansiblelogo.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "856",
        "ok": "-",
        "ko": "856"
    },
    "maxResponseTime": {
        "total": "2403",
        "ok": "-",
        "ko": "2403"
    },
    "meanResponseTime": {
        "total": "2120",
        "ok": "-",
        "ko": "2120"
    },
    "standardDeviation": {
        "total": "181",
        "ok": "-",
        "ko": "181"
    },
    "percentiles1": {
        "total": "2088",
        "ok": "-",
        "ko": "2088"
    },
    "percentiles2": {
        "total": "2195",
        "ok": "-",
        "ko": "2195"
    },
    "percentiles3": {
        "total": "2343",
        "ok": "-",
        "ko": "2343"
    },
    "percentiles4": {
        "total": "2366",
        "ok": "-",
        "ko": "2366"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_sparta-global-l-d5d11": {
        type: "REQUEST",
        name: "Sparta-global-logo-white.svg",
path: "Sparta-global-logo-white.svg",
pathFormatted: "req_sparta-global-l-d5d11",
stats: {
    "name": "Sparta-global-logo-white.svg",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "840",
        "ok": "-",
        "ko": "840"
    },
    "maxResponseTime": {
        "total": "2372",
        "ok": "-",
        "ko": "2372"
    },
    "meanResponseTime": {
        "total": "2094",
        "ok": "-",
        "ko": "2094"
    },
    "standardDeviation": {
        "total": "230",
        "ok": "-",
        "ko": "230"
    },
    "percentiles1": {
        "total": "2078",
        "ok": "-",
        "ko": "2078"
    },
    "percentiles2": {
        "total": "2183",
        "ok": "-",
        "ko": "2183"
    },
    "percentiles3": {
        "total": "2339",
        "ok": "-",
        "ko": "2339"
    },
    "percentiles4": {
        "total": "2359",
        "ok": "-",
        "ko": "2359"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_jenkins-jpg-366ea": {
        type: "REQUEST",
        name: "jenkins.jpg",
path: "jenkins.jpg",
pathFormatted: "req_jenkins-jpg-366ea",
stats: {
    "name": "jenkins.jpg",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "857",
        "ok": "-",
        "ko": "857"
    },
    "maxResponseTime": {
        "total": "2368",
        "ok": "-",
        "ko": "2368"
    },
    "meanResponseTime": {
        "total": "2123",
        "ok": "-",
        "ko": "2123"
    },
    "standardDeviation": {
        "total": "182",
        "ok": "-",
        "ko": "182"
    },
    "percentiles1": {
        "total": "2091",
        "ok": "-",
        "ko": "2091"
    },
    "percentiles2": {
        "total": "2198",
        "ok": "-",
        "ko": "2198"
    },
    "percentiles3": {
        "total": "2348",
        "ok": "-",
        "ko": "2348"
    },
    "percentiles4": {
        "total": "2362",
        "ok": "-",
        "ko": "2362"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_awslogo-png-32175": {
        type: "REQUEST",
        name: "awslogo.png",
path: "awslogo.png",
pathFormatted: "req_awslogo-png-32175",
stats: {
    "name": "awslogo.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "860",
        "ok": "-",
        "ko": "860"
    },
    "maxResponseTime": {
        "total": "2370",
        "ok": "-",
        "ko": "2370"
    },
    "meanResponseTime": {
        "total": "2125",
        "ok": "-",
        "ko": "2125"
    },
    "standardDeviation": {
        "total": "181",
        "ok": "-",
        "ko": "181"
    },
    "percentiles1": {
        "total": "2092",
        "ok": "-",
        "ko": "2092"
    },
    "percentiles2": {
        "total": "2194",
        "ok": "-",
        "ko": "2194"
    },
    "percentiles3": {
        "total": "2349",
        "ok": "-",
        "ko": "2349"
    },
    "percentiles4": {
        "total": "2369",
        "ok": "-",
        "ko": "2369"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_python-png-fd9e7": {
        type: "REQUEST",
        name: "python.png",
path: "python.png",
pathFormatted: "req_python-png-fd9e7",
stats: {
    "name": "python.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "1131",
        "ok": "-",
        "ko": "1131"
    },
    "maxResponseTime": {
        "total": "2941",
        "ok": "-",
        "ko": "2941"
    },
    "meanResponseTime": {
        "total": "2009",
        "ok": "-",
        "ko": "2009"
    },
    "standardDeviation": {
        "total": "483",
        "ok": "-",
        "ko": "483"
    },
    "percentiles1": {
        "total": "2010",
        "ok": "-",
        "ko": "2010"
    },
    "percentiles2": {
        "total": "2354",
        "ok": "-",
        "ko": "2354"
    },
    "percentiles3": {
        "total": "2725",
        "ok": "-",
        "ko": "2725"
    },
    "percentiles4": {
        "total": "2934",
        "ok": "-",
        "ko": "2934"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_docker-png-99363": {
        type: "REQUEST",
        name: "docker.png",
path: "docker.png",
pathFormatted: "req_docker-png-99363",
stats: {
    "name": "docker.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "1130",
        "ok": "-",
        "ko": "1130"
    },
    "maxResponseTime": {
        "total": "2833",
        "ok": "-",
        "ko": "2833"
    },
    "meanResponseTime": {
        "total": "1979",
        "ok": "-",
        "ko": "1979"
    },
    "standardDeviation": {
        "total": "485",
        "ok": "-",
        "ko": "485"
    },
    "percentiles1": {
        "total": "1987",
        "ok": "-",
        "ko": "1987"
    },
    "percentiles2": {
        "total": "2457",
        "ok": "-",
        "ko": "2457"
    },
    "percentiles3": {
        "total": "2721",
        "ok": "-",
        "ko": "2721"
    },
    "percentiles4": {
        "total": "2784",
        "ok": "-",
        "ko": "2784"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_sql-jpg-056c2": {
        type: "REQUEST",
        name: "SQL.jpg",
path: "SQL.jpg",
pathFormatted: "req_sql-jpg-056c2",
stats: {
    "name": "SQL.jpg",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "1121",
        "ok": "-",
        "ko": "1121"
    },
    "maxResponseTime": {
        "total": "2760",
        "ok": "-",
        "ko": "2760"
    },
    "meanResponseTime": {
        "total": "1964",
        "ok": "-",
        "ko": "1964"
    },
    "standardDeviation": {
        "total": "474",
        "ok": "-",
        "ko": "474"
    },
    "percentiles1": {
        "total": "1974",
        "ok": "-",
        "ko": "1974"
    },
    "percentiles2": {
        "total": "2358",
        "ok": "-",
        "ko": "2358"
    },
    "percentiles3": {
        "total": "2675",
        "ok": "-",
        "ko": "2675"
    },
    "percentiles4": {
        "total": "2748",
        "ok": "-",
        "ko": "2748"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_github-png-3a297": {
        type: "REQUEST",
        name: "GitHub.png",
path: "GitHub.png",
pathFormatted: "req_github-png-3a297",
stats: {
    "name": "GitHub.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "1152",
        "ok": "-",
        "ko": "1152"
    },
    "maxResponseTime": {
        "total": "2814",
        "ok": "-",
        "ko": "2814"
    },
    "meanResponseTime": {
        "total": "1955",
        "ok": "-",
        "ko": "1955"
    },
    "standardDeviation": {
        "total": "466",
        "ok": "-",
        "ko": "466"
    },
    "percentiles1": {
        "total": "1971",
        "ok": "-",
        "ko": "1971"
    },
    "percentiles2": {
        "total": "2333",
        "ok": "-",
        "ko": "2333"
    },
    "percentiles3": {
        "total": "2675",
        "ok": "-",
        "ko": "2675"
    },
    "percentiles4": {
        "total": "2782",
        "ok": "-",
        "ko": "2782"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_vagrant-png-6546e": {
        type: "REQUEST",
        name: "vagrant.png",
path: "vagrant.png",
pathFormatted: "req_vagrant-png-6546e",
stats: {
    "name": "vagrant.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "1145",
        "ok": "-",
        "ko": "1145"
    },
    "maxResponseTime": {
        "total": "2884",
        "ok": "-",
        "ko": "2884"
    },
    "meanResponseTime": {
        "total": "1958",
        "ok": "-",
        "ko": "1958"
    },
    "standardDeviation": {
        "total": "471",
        "ok": "-",
        "ko": "471"
    },
    "percentiles1": {
        "total": "1970",
        "ok": "-",
        "ko": "1970"
    },
    "percentiles2": {
        "total": "2332",
        "ok": "-",
        "ko": "2332"
    },
    "percentiles3": {
        "total": "2673",
        "ok": "-",
        "ko": "2673"
    },
    "percentiles4": {
        "total": "2856",
        "ok": "-",
        "ko": "2856"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_linux-jpg-d003a": {
        type: "REQUEST",
        name: "linux.jpg",
path: "linux.jpg",
pathFormatted: "req_linux-jpg-d003a",
stats: {
    "name": "linux.jpg",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "679",
        "ok": "-",
        "ko": "679"
    },
    "maxResponseTime": {
        "total": "2912",
        "ok": "-",
        "ko": "2912"
    },
    "meanResponseTime": {
        "total": "1449",
        "ok": "-",
        "ko": "1449"
    },
    "standardDeviation": {
        "total": "450",
        "ok": "-",
        "ko": "450"
    },
    "percentiles1": {
        "total": "1475",
        "ok": "-",
        "ko": "1475"
    },
    "percentiles2": {
        "total": "1614",
        "ok": "-",
        "ko": "1614"
    },
    "percentiles3": {
        "total": "2257",
        "ok": "-",
        "ko": "2257"
    },
    "percentiles4": {
        "total": "2908",
        "ok": "-",
        "ko": "2908"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_microservices-j-21f2e": {
        type: "REQUEST",
        name: "microservices.jpg",
path: "microservices.jpg",
pathFormatted: "req_microservices-j-21f2e",
stats: {
    "name": "microservices.jpg",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "308",
        "ok": "-",
        "ko": "308"
    },
    "maxResponseTime": {
        "total": "4428",
        "ok": "-",
        "ko": "4428"
    },
    "meanResponseTime": {
        "total": "1546",
        "ok": "-",
        "ko": "1546"
    },
    "standardDeviation": {
        "total": "1361",
        "ok": "-",
        "ko": "1361"
    },
    "percentiles1": {
        "total": "704",
        "ok": "-",
        "ko": "704"
    },
    "percentiles2": {
        "total": "2948",
        "ok": "-",
        "ko": "2948"
    },
    "percentiles3": {
        "total": "4391",
        "ok": "-",
        "ko": "4391"
    },
    "percentiles4": {
        "total": "4420",
        "ok": "-",
        "ko": "4420"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_nginx-png-d2eb2": {
        type: "REQUEST",
        name: "nginx.png",
path: "nginx.png",
pathFormatted: "req_nginx-png-d2eb2",
stats: {
    "name": "nginx.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "442",
        "ok": "-",
        "ko": "442"
    },
    "maxResponseTime": {
        "total": "4428",
        "ok": "-",
        "ko": "4428"
    },
    "meanResponseTime": {
        "total": "1616",
        "ok": "-",
        "ko": "1616"
    },
    "standardDeviation": {
        "total": "1332",
        "ok": "-",
        "ko": "1332"
    },
    "percentiles1": {
        "total": "699",
        "ok": "-",
        "ko": "699"
    },
    "percentiles2": {
        "total": "2975",
        "ok": "-",
        "ko": "2975"
    },
    "percentiles3": {
        "total": "4388",
        "ok": "-",
        "ko": "4388"
    },
    "percentiles4": {
        "total": "4403",
        "ok": "-",
        "ko": "4403"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_flask-png-4a5af": {
        type: "REQUEST",
        name: "flask.png",
path: "flask.png",
pathFormatted: "req_flask-png-4a5af",
stats: {
    "name": "flask.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "432",
        "ok": "-",
        "ko": "432"
    },
    "maxResponseTime": {
        "total": "4427",
        "ok": "-",
        "ko": "4427"
    },
    "meanResponseTime": {
        "total": "1593",
        "ok": "-",
        "ko": "1593"
    },
    "standardDeviation": {
        "total": "1406",
        "ok": "-",
        "ko": "1406"
    },
    "percentiles1": {
        "total": "625",
        "ok": "-",
        "ko": "625"
    },
    "percentiles2": {
        "total": "3152",
        "ok": "-",
        "ko": "3152"
    },
    "percentiles3": {
        "total": "4390",
        "ok": "-",
        "ko": "4390"
    },
    "percentiles4": {
        "total": "4403",
        "ok": "-",
        "ko": "4403"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_kubernetes-png-17e22": {
        type: "REQUEST",
        name: "kubernetes.png",
path: "kubernetes.png",
pathFormatted: "req_kubernetes-png-17e22",
stats: {
    "name": "kubernetes.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "422",
        "ok": "-",
        "ko": "422"
    },
    "maxResponseTime": {
        "total": "4394",
        "ok": "-",
        "ko": "4394"
    },
    "meanResponseTime": {
        "total": "1235",
        "ok": "-",
        "ko": "1235"
    },
    "standardDeviation": {
        "total": "1177",
        "ok": "-",
        "ko": "1177"
    },
    "percentiles1": {
        "total": "556",
        "ok": "-",
        "ko": "556"
    },
    "percentiles2": {
        "total": "1705",
        "ok": "-",
        "ko": "1705"
    },
    "percentiles3": {
        "total": "3206",
        "ok": "-",
        "ko": "3206"
    },
    "percentiles4": {
        "total": "4393",
        "ok": "-",
        "ko": "4393"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_agile-png-1b8f0": {
        type: "REQUEST",
        name: "agile.png",
path: "agile.png",
pathFormatted: "req_agile-png-1b8f0",
stats: {
    "name": "agile.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "419",
        "ok": "-",
        "ko": "419"
    },
    "maxResponseTime": {
        "total": "3219",
        "ok": "-",
        "ko": "3219"
    },
    "meanResponseTime": {
        "total": "948",
        "ok": "-",
        "ko": "948"
    },
    "standardDeviation": {
        "total": "939",
        "ok": "-",
        "ko": "939"
    },
    "percentiles1": {
        "total": "504",
        "ok": "-",
        "ko": "504"
    },
    "percentiles2": {
        "total": "608",
        "ok": "-",
        "ko": "608"
    },
    "percentiles3": {
        "total": "3183",
        "ok": "-",
        "ko": "3183"
    },
    "percentiles4": {
        "total": "3209",
        "ok": "-",
        "ko": "3209"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_teams-png-9e345": {
        type: "REQUEST",
        name: "teams.png",
path: "teams.png",
pathFormatted: "req_teams-png-9e345",
stats: {
    "name": "teams.png",
    "numberOfRequests": {
        "total": "80",
        "ok": "0",
        "ko": "80"
    },
    "minResponseTime": {
        "total": "408",
        "ok": "-",
        "ko": "408"
    },
    "maxResponseTime": {
        "total": "2948",
        "ok": "-",
        "ko": "2948"
    },
    "meanResponseTime": {
        "total": "543",
        "ok": "-",
        "ko": "543"
    },
    "standardDeviation": {
        "total": "301",
        "ok": "-",
        "ko": "301"
    },
    "percentiles1": {
        "total": "505",
        "ok": "-",
        "ko": "505"
    },
    "percentiles2": {
        "total": "527",
        "ok": "-",
        "ko": "527"
    },
    "percentiles3": {
        "total": "702",
        "ok": "-",
        "ko": "702"
    },
    "percentiles4": {
        "total": "1610",
        "ok": "-",
        "ko": "1610"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 80,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "-",
        "ko": "5"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "221",
        "ok": "221",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3639",
        "ok": "3639",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "771",
        "ok": "771",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "912",
        "ok": "912",
        "ko": "-"
    },
    "percentiles1": {
        "total": "391",
        "ok": "391",
        "ko": "-"
    },
    "percentiles2": {
        "total": "541",
        "ok": "541",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3151",
        "ok": "3151",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3260",
        "ok": "3260",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 62,
    "percentage": 78
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 15,
    "percentage": 19
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "137",
        "ok": "137",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6692",
        "ok": "6692",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1057",
        "ok": "1057",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1202",
        "ok": "1202",
        "ko": "-"
    },
    "percentiles1": {
        "total": "536",
        "ok": "536",
        "ko": "-"
    },
    "percentiles2": {
        "total": "907",
        "ok": "907",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3179",
        "ok": "3179",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4305",
        "ok": "4305",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 53,
    "percentage": 66
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 8,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 19,
    "percentage": 24
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "134",
        "ok": "134",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3667",
        "ok": "3667",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "948",
        "ok": "948",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1009",
        "ok": "1009",
        "ko": "-"
    },
    "percentiles1": {
        "total": "415",
        "ok": "415",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1273",
        "ok": "1273",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3606",
        "ok": "3606",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3646",
        "ok": "3646",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 53,
    "percentage": 66
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 25,
    "percentage": 31
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "65",
        "ok": "65",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3660",
        "ok": "3660",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "990",
        "ok": "990",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1103",
        "ok": "1103",
        "ko": "-"
    },
    "percentiles1": {
        "total": "397",
        "ok": "397",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1323",
        "ok": "1323",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3494",
        "ok": "3494",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3653",
        "ok": "3653",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 54,
    "percentage": 68
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 23,
    "percentage": 29
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "67",
        "ok": "67",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3644",
        "ok": "3644",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1068",
        "ok": "1068",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1141",
        "ok": "1141",
        "ko": "-"
    },
    "percentiles1": {
        "total": "571",
        "ok": "571",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1275",
        "ok": "1275",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3618",
        "ok": "3618",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3642",
        "ok": "3642",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 52,
    "percentage": 65
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 24,
    "percentage": 30
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "83",
        "ok": "83",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4276",
        "ok": "4276",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1253",
        "ok": "1253",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1266",
        "ok": "1266",
        "ko": "-"
    },
    "percentiles1": {
        "total": "492",
        "ok": "492",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1913",
        "ok": "1913",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3571",
        "ok": "3571",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3823",
        "ok": "3823",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 46,
    "percentage": 57
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 30,
    "percentage": 38
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "79",
        "ok": "79",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3475",
        "ok": "3475",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "742",
        "ok": "742",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1016",
        "ok": "1016",
        "ko": "-"
    },
    "percentiles1": {
        "total": "279",
        "ok": "279",
        "ko": "-"
    },
    "percentiles2": {
        "total": "450",
        "ok": "450",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3453",
        "ok": "3453",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3473",
        "ok": "3473",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 63,
    "percentage": 79
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 16,
    "percentage": 20
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "34",
        "ok": "34",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6797",
        "ok": "6797",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "743",
        "ok": "743",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1127",
        "ok": "1127",
        "ko": "-"
    },
    "percentiles1": {
        "total": "279",
        "ok": "279",
        "ko": "-"
    },
    "percentiles2": {
        "total": "513",
        "ok": "513",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3069",
        "ok": "3069",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5403",
        "ok": "5403",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 63,
    "percentage": 79
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 17,
    "percentage": 21
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "33",
        "ok": "33",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3489",
        "ok": "3489",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "676",
        "ok": "676",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "859",
        "ok": "859",
        "ko": "-"
    },
    "percentiles1": {
        "total": "254",
        "ok": "254",
        "ko": "-"
    },
    "percentiles2": {
        "total": "767",
        "ok": "767",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3050",
        "ok": "3050",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3487",
        "ok": "3487",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 60,
    "percentage": 75
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 19,
    "percentage": 24
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-10-1cfbe": {
        type: "REQUEST",
        name: "request_10",
path: "request_10",
pathFormatted: "req_request-10-1cfbe",
stats: {
    "name": "request_10",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3039",
        "ok": "3039",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "378",
        "ok": "378",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "424",
        "ok": "424",
        "ko": "-"
    },
    "percentiles1": {
        "total": "251",
        "ok": "251",
        "ko": "-"
    },
    "percentiles2": {
        "total": "275",
        "ok": "275",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1247",
        "ok": "1247",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1662",
        "ok": "1662",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 71,
    "percentage": 89
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-11-f11e8": {
        type: "REQUEST",
        name: "request_11",
path: "request_11",
pathFormatted: "req_request-11-f11e8",
stats: {
    "name": "request_11",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3330",
        "ok": "3330",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "514",
        "ok": "514",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "644",
        "ok": "644",
        "ko": "-"
    },
    "percentiles1": {
        "total": "249",
        "ok": "249",
        "ko": "-"
    },
    "percentiles2": {
        "total": "327",
        "ok": "327",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1288",
        "ok": "1288",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3088",
        "ok": "3088",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 64,
    "percentage": 80
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 15,
    "percentage": 19
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-12-61da2": {
        type: "REQUEST",
        name: "request_12",
path: "request_12",
pathFormatted: "req_request-12-61da2",
stats: {
    "name": "request_12",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1295",
        "ok": "1295",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "334",
        "ok": "334",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "284",
        "ok": "284",
        "ko": "-"
    },
    "percentiles1": {
        "total": "251",
        "ok": "251",
        "ko": "-"
    },
    "percentiles2": {
        "total": "272",
        "ok": "272",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1173",
        "ok": "1173",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1286",
        "ok": "1286",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 74,
    "percentage": 93
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 5
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-13-5cca6": {
        type: "REQUEST",
        name: "request_13",
path: "request_13",
pathFormatted: "req_request-13-5cca6",
stats: {
    "name": "request_13",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1311",
        "ok": "1311",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "340",
        "ok": "340",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "percentiles1": {
        "total": "261",
        "ok": "261",
        "ko": "-"
    },
    "percentiles2": {
        "total": "284",
        "ok": "284",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1257",
        "ok": "1257",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1307",
        "ok": "1307",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 73,
    "percentage": 91
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-14-a0e30": {
        type: "REQUEST",
        name: "request_14",
path: "request_14",
pathFormatted: "req_request-14-a0e30",
stats: {
    "name": "request_14",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3029",
        "ok": "3029",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "281",
        "ok": "281",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "351",
        "ok": "351",
        "ko": "-"
    },
    "percentiles1": {
        "total": "249",
        "ok": "249",
        "ko": "-"
    },
    "percentiles2": {
        "total": "261",
        "ok": "261",
        "ko": "-"
    },
    "percentiles3": {
        "total": "445",
        "ok": "445",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1656",
        "ok": "1656",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 77,
    "percentage": 96
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 3
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-15-56eac": {
        type: "REQUEST",
        name: "request_15",
path: "request_15",
pathFormatted: "req_request-15-56eac",
stats: {
    "name": "request_15",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1238",
        "ok": "1238",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "247",
        "ok": "247",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "177",
        "ok": "177",
        "ko": "-"
    },
    "percentiles1": {
        "total": "246",
        "ok": "246",
        "ko": "-"
    },
    "percentiles2": {
        "total": "261",
        "ok": "261",
        "ko": "-"
    },
    "percentiles3": {
        "total": "450",
        "ok": "450",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1195",
        "ok": "1195",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 78,
    "percentage": 98
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-16-24733": {
        type: "REQUEST",
        name: "request_16",
path: "request_16",
pathFormatted: "req_request-16-24733",
stats: {
    "name": "request_16",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3047",
        "ok": "3047",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "292",
        "ok": "292",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "457",
        "ok": "457",
        "ko": "-"
    },
    "percentiles1": {
        "total": "246",
        "ok": "246",
        "ko": "-"
    },
    "percentiles2": {
        "total": "265",
        "ok": "265",
        "ko": "-"
    },
    "percentiles3": {
        "total": "352",
        "ok": "352",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3043",
        "ok": "3043",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 77,
    "percentage": 96
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 3
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-17-cd6a2": {
        type: "REQUEST",
        name: "request_17",
path: "request_17",
pathFormatted: "req_request-17-cd6a2",
stats: {
    "name": "request_17",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1028",
        "ok": "1028",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "225",
        "ok": "225",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "124",
        "ok": "124",
        "ko": "-"
    },
    "percentiles1": {
        "total": "253",
        "ok": "253",
        "ko": "-"
    },
    "percentiles2": {
        "total": "268",
        "ok": "268",
        "ko": "-"
    },
    "percentiles3": {
        "total": "293",
        "ok": "293",
        "ko": "-"
    },
    "percentiles4": {
        "total": "591",
        "ok": "591",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 79,
    "percentage": 99
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    },"req_request-20-6804b": {
        type: "REQUEST",
        name: "request_20",
path: "request_20",
pathFormatted: "req_request-20-6804b",
stats: {
    "name": "request_20",
    "numberOfRequests": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1221",
        "ok": "1221",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "189",
        "ok": "189",
        "ko": "-"
    },
    "percentiles1": {
        "total": "240",
        "ok": "240",
        "ko": "-"
    },
    "percentiles2": {
        "total": "256",
        "ok": "256",
        "ko": "-"
    },
    "percentiles3": {
        "total": "293",
        "ok": "293",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1064",
        "ok": "1064",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 77,
    "percentage": 96
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
